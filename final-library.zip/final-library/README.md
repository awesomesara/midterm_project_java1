```properties
spring_profiles_active=prod
PROD_DB_HOST=containers.railway.app
PROD_DB_PORT=6946
PROD_DB_NAME=railway
PROD_DB_USERNAME=postgres
PROD_DB_PASSWORD=DDasrLmhqMqrQUlhYCdE
```