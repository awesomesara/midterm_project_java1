package kg.alatoo.demooauth.bookdto;


import lombok.Data;


@Data
public class BookDTO {

    private int id;
    private String author;
    private String name;
    private String price;
    private String imageName;

}
